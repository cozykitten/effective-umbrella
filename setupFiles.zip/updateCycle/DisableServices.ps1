Write-Host "Disabling unnecessary System Services"
Write-Host "`n"

# Windows Presentation [...] 3.0.0.0		3 safe / 4 should be safe / default 3 (used by VS mby)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\FontCache3.0.0.0" "Start" 3

# Parental Control 				4 safe / default 3 (no dependencies)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WpcMonSvc" "Start" 4

# Payments and NFC/SE Manager			4 safe / me 4 (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SEMgrSvc" "Start" 4

# Phone Service				4 safe me / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PhoneSvc" "Start" 4

# Windows Error Reporting Service		4 safe me / 3 default (no dependend children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WerSvc" "Start" 4

# Windows Event Collector			3 safe me default / 4 safe (no dependent children) 
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Wecsvc" "Start" 4

# Radio Management Service			3 safe default / 4 safe-under-conditions (no dependend children)
# condition: not using radio and airplane mode
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RmSvc" "Start" 4

# Microsoft Edge Update Service		4 safe-under-conditions / 2 default (no dependent children)
# condition: if you dont use edge		
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\edgeupdate" "Start" 4

# Microsoft Edge Update Service		4 safe-under-conditions / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\edgeupdatem" "Start" 4

# Microsoft Edge Elevation Service		4 safe-under-conditions / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MicrosoftEdgeElevationService" "Start" 4

# SysMain (Superfetch) 			4 safe / 2 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SysMain" "Start" 4

# Windows Insider Service			4 safe / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\wisvc" "Start" 4

# Retail Demo Service				4 safe / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RetailDemo" "Start" 4

# Touch Keyboard and Handwriting Panel Service	4 safe-under-conditions / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\TabletInputService" "Start" 4

# WAP Push Message Routing Service		4 safe / 3 default	
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\dmwappushservice" "Start" 4


Write-Host "completed"
