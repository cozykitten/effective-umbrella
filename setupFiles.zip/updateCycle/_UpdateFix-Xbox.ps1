$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-Not ($currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))) {
	write-host "Warning: This script needs to run as administrator." -ForegroundColor Red
}
else {

# Never skip creating a restore point
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name SystemRestorePointCreationFrequency -PropertyType DWord -Value 0 -Force

Checkpoint-Computer -Description "Update Cycle reapply" -RestorePointType MODIFY_SETTINGS

# Revert the System Restore checkpoint creation frequency to 1440 minutes (default is 0 (automatic disabled) though)
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name SystemRestorePointCreationFrequency -PropertyType DWord -Value 1440 -Force

write-host "Please check that a restore point has been created or manually create one." -ForegroundColor Red
Read-Host -Prompt "Press any key to continue"


# Start applying settings
Write-Host "`n1: Decrapifier" -ForegroundColor Green
.\decrapifier.ps1 -SettingsOnly -Xbox

Reg Add "HKCU\Control Panel\International\User Profile" /T REG_DWORD /V "HttpAcceptLanguageOptOut" /D 1 /F
Reg Add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /T REG_DWORD /V "GlobalUserDisabled" /D 1 /F
Reg Add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /T REG_DWORD /V "BackgroundAppGlobalToggle" /D 0 /F


Write-Host "`n2: Disable-Services" -ForegroundColor Green
.\disable-services-xbox.ps1
.\DisableServices.ps1


Write-Host "`n3: Fix-Privacy" -ForegroundColor Green
.\fix-privacy-settings.ps1

reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Spynet" /t REG_DWORD /v "SpyNetReporting" /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Spynet" /t REG_DWORD /v "SubmitSamplesConsent" /d 0 /f


Write-Host "`n4: Disable-Autologgers" -ForegroundColor Green
.\Autologger.bat


Write-Host "5: Disable-Telemetry" -ForegroundColor Green
.\DisableTelemetry.bat
.\Safe_custom.bat


Write-Host "`n`n6: Run OOSU10 and Sophia preset next and reboot" -ForegroundColor Green
}