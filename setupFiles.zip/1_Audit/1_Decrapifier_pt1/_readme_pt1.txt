ctrl+shift+f3 for Audit mode

shift right click on some empty space in the open folder
click "open Powershell window here"

In Powershell window:

copy paste (right click) : Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
if you want to keep Xbox 
copy paste : .\decrapifier.ps1 -SettingsOnly -Xbox
else
copy paste : .\decrapifier.ps1 -SettingsOnly

run the contents in GPedit and VC_Redist&dotNetRuntime

when done look at the little sysprep window on the desktop
select ->	system cleanup action: "enter OOBE"
		shutdown options: "reboot"

hit confirm or restart or whatever it says