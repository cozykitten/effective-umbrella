
1. Disable Indexing

search for "indexing options", it should open a control panel window
click on "modify", then "show all locations"
click any folder in the lower half, it'll open a tree in the uper half, uncheck the tick mark.
do that for all folders, then choose "okay" to close the indexing options



2. Settings

System:
Notification settings, you can disable certain programs or turn notifications off alltogether if it annoys you


Devices:
Idk what Autocorrect is supposed to correct, I've never seen it work, browser & discord have their own spellchecking... so


Network and Internet:
Select your connection, f.e. Ethernet
Click on "Edit" next to "DNS server assignment"
If "Preferred DNS" and "Alternative DNS" for IPv4 don't show 1.1.1.1 and 1.0.0.1 respectively then enter those.
Turn on IPv6 and paste 2606:4700:4700::1111 for "Preferred DNS" and 2606:4700:4700::1001 for "Alternative DNS"
repeat this for other Network adapters if you see more (wifi & ethernet)


Accounts:
Sign-in options might need a full minute to load the menu since some Windows Hello components such as face and image sign in got removed.
If you want to change your password, you can still do it that way, or faster in command line. (net user Your_Username New_Password)


Time & language:
Typing: Turn off text suggestions, Autocorrect, Highlighting, Typing insights


Gaming:
Xbox Game Bar: whatever that is
Game Mode: turn it off, it might help on low end PC's but actually cause problems on high end PC's or in some games.


Privacy & security:
Windows Security -> Open Windows Security
Virus and threat protection is probably red, warning about a Possible Hosts File Hijack (thats blocking ad and telemetry domains from microsoft)
expand the notification and choose "allow on device" and then "start actions".

Apps and browser control might also be yellow, click the "link" "reputation-based protection settings" and dismiss all yellow warnings.
Or you might just wanna turn off the App & browser control setting anyway since you dont use edge.

remark:
Reputation based protection (SmartScreen) just means sending the urls you visit to microsoft to check them vs a database.
But it only works in Edge and Store Apps, since you don't use edge and only the preinstalled store apps theres nothing to weigh up the privacy converns.

Device security:
Turning on Core isolation might be a good idea.

closing Windows Security - back in Settings app Privacy & security:
Make sure Inking & typing personalisation as well as Activity history are disabled.

Search permissions -> Turn off and clear search history


Windows Update:
Advanced options -> Active hours: You can set your active hours manually or let windows set them automatically based on devices usage.



2. Control Panel:

Power Options:
for your selected plan (probably balanced) click "change plan settings" -> change advanced power settings
Sleep -> allow wake timers: off
PCIE -> link state power saving...: off
Processor power management -> minimum: 0

Windows Defender Firewall:
Allow an app or feature through the firewall:
Click on "change settings" and untick the following:
- Delivery Optimization
- Microsoft Photos
- Start
- Windows Calculator
- Your Account



3. Maintenance:
search for disk cleanup, (ctrl + shift + enter) does the same as clicking "run as admin"
you can check everything then click "okay"
It is set to shows up every 15 days, you can disable that in Task Scheduler -> custom, but run it once in a while, mainly to clean up after windows update.

Optimise Drives automatically runs every day, if thats too frequent for you mby set it to a week (just search in windows search)
that said with ssds its done in 10 seconds anyway.
