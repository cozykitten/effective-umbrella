
run any script as admin



usersettings - recommended

faster doubleclick speed, setting default priority, less menu delay
you can just run this, or open and adjust it to your liking



enable windows photo viewer - recommended

restores the windows photo viewer app that was used before "photos" app.
why? cause the new one is annoyingly slow, cant zoom with scrollwheel and cant cycle through all images with arrow keys
even when enabled it doesnt disable photos app, it just enables windows photo viewer again
so you can "open with" windows photo viewer and set that as default if you like.



paint contextmenu

adds the "edit with Paint" context menu entry for images, opening image files in paint



Webview2 Runtime

https://go.microsoft.com/fwlink/p/?LinkId=2124703
Needed for some applications, such as TcNo Account Switcher.
Run installer as admin for it to install correctly in Program Files instead of AppData Local.
After installation, disable edgeupdate and edgeupdatem services as well as the two related tasks in Task Scheduler



DirectX runtimes for DX9-11

https://www.microsoft.com/en-us/download/details.aspx?id=8109
Required for some older games or support of those.
Note that this package does not modify the DirectX Runtime installed on your Windows OS in any way,
as such there is no harm in installing them.



addAdminShellToContext

adds "Run Powershell as administrator" to shift + rightclick context menu to allow easier access to an admin powershell in the current directory.
addDefaultShellToContext restores the non admin powershell if you removed it previously (it is already added by default).



Launchers-services

disables unnecessary background services from Epic, Origin, and Google Chrome
they run just fine without, just Steam needs them so I removed them from that list.
the google services are update services to always check automaticaly for updates..
cause apparently it's too hard for users to click on the "new update" notification in their browser.
Services aren't difficult to disable or re-enable so if you feel like you probably don't need it its fine to disable them for now.



Services-experimental - read first

more windows services which should be safe, just might be attached to some conditions.
f.e. you might not need fax, scanner and printing services if you dont use a printer on your computer.

Each service is commented, so you can edit it for yourself, don't just run it blindly.
4 = disabled, 3 = manual (can be triggered by programs) 2 = automatically (starts at boot)

Also I'd recommend you wait a few weeks and see if everything is fine before running the additional stuff.
In case you just run it blindly anyway there's also a revert file which reverts them to their defaults.



optional-tweaks
If there's something you'd like to apply, copy paste the line starting with "reg add" into an admin console
contains: slightly wider desktop icon setting & enable clear recently opened files on shutdown



no-store_additional-services - not recommended
if you dont have or use the store you can disable associated services, keep an eye on the next windows update.



custom_win_on_ARM_extract - not recommended

basically just adds 2 keys to disable wifisharing (but I can't check that cause I don't have wifi)
and some to prevent windows from automatically changing links (shortcuts) when their original target isn't found.
shouldn't cause any problems, just unnecessary,.. well I need the link fix tho.