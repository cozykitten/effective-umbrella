Write-Host "***networking p2p stuff***"

# Peer Networking Identity Manager	(p2pimsvc)			3 safe default / 4 should be safe
# dependent children: Peer Name Resolution Protocol (PNRPsvc), Peer Networking Grouping (p2psvc)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\p2pimsvc" "Start" 4

# Peer Name Resolution Protocol (PNRPsvc)				3 safe default / 4 should be safe
# dependent children: Peer Networking Grouping (p2psvc), PNRP Machine Name Publication Service (PNRPAutoReg)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PNRPsvc" "Start" 4

# Peer Networking Grouping (p2psvc)				3 safe default / 4 should be safe
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\p2psvc" "Start" 4

# PNRP Machine Name Publication Service (PNRPAutoReg)		3 safe default / 4 should be safe
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PNRPAutoReg" "Start" 4
Write-Host "`n"



Write-Host "*** mail, contacts, calendar ***"

# Sync Host						2 default / 3 default after scripts
# condition: mail, contacts, calendar might depend on this, required for time sync on 3
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\OneSyncSvc" "Start" 3

# User Data Storage					3 safe default / 4 safe-under-condition (2 dependent children)
# condition: handles data for contact info, calendars, messages
# children: Contact Data (PimIndexMaintenanceSvc) & User Data Access (UserDataSvc)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\UnistoreSvc" "Start" 4

# Contact Data					3 safe default / 4 safe-under-condition (no dependent children)
# condition: needed for contact data and contact searching
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PimIndexMaintenanceSvc" "Start" 4

# User Data Access					3 safe default / 4 safe-under-condition (no dependent children)
# condition: handles data for contact info, calendars, messages
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\UserDataSvc" "Start" 4
Write-Host "`n"



Write-Host "***bluetooth***"

# Bluetooth Audio Gateway Service				3 safe default / 4 safe-under-conditions (no dependend children)
# condition: configures cortana over bluetooth, disable if no issues with bluetooth
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\BTAGService" "Start" 4

# bluetooth support service				3 safe default / 4 safe-under-conditions (1 dependend child)		
# condition: leave 3 if you have / use bluetooth
# children: Bluetooth User Support Service (BluetoothUserService)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\bthserv" "Start" 3

# Bluetooth User Support Service				3 safe default / 4 safe-under-conditions (no dependend children)
# condition: leave 3 if you have / use bluetooth
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\BluetoothUserService" "Start" 3
Write-Host "`n"



Write-Host "***smart cards***"

# Smart Card					4 safe / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SCardSvr" "Start" 4

# Smart Card Device Enumeration Service		4 safe / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\ScDeviceEnum" "Start" 4

# Smart Card #oval Policy			4 safe / 3 default (no dependent children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SCPolicySvc" "Start" 4
Write-Host "`n"



Write-Host "***Sensors***"

# Sensor Service 						4 safe-under-condition / default 3 (no dependencies) (device orientation)
# condition: safe on desktop, 3 for tablets
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SensorService" "Start" 4

# Sensor Data Service			4 safe / 3 default (no dependencies)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SensorDataService" "Start" 4

# Sensor Monitoring Service 		4 safe-under-condition / default 3 (no dependencies)
# condition: automatic brightness, 3 for laptop, 4 for desktop
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SensrSvc" "Start" 4
Write-Host "`n"



Write-Host "***printing, scanning, fax***"

# Print Spooler						2 safe default / 4 safe-under-conditions (one dependend child)
# condition: disable if you dont use a printer
# children: fax
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" "Start" 2

# Fax							3 safe default / 4 safe-under-conditions (no dependend children)
# conditions: do you use fax?
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Fax" "Start" 4

# Windows Image Acquisition (WIA)		3 safe / 2 default / 4 safe-under-conditions (no dependant children) (scanner & camera)
# condition: disable if you dont use scanner / printer
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\StiSvc" "Start" 3
Write-Host "`n"



Write-Host "***random stuff***"

# Telephony 						3 safe default / 4 experimental (1 dependent child)
# condition: #ote access connection might depend on this -> vpn, might also be necessary for wifi
# children: Fax (Fax)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\TapiSrv" "Start" 4

# Data Usage						2 safe default / 3 safe-under-conditions (no dependent children)
# condition: disables data usage overview in settings & data limit if set to 3
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\DusmSvc" "Start" 2

# Workstation (LanmanWorkstation)				3 should be safe / 4 should be safe / 2 default (2 dependent children)
# dependent children: Netlogon(Netlogon), remote Desktop Configuration (SessionEnv) (disabled)
# might also be necessary for wifi
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" "Start" 3

# #ote Desktop Configuration				4 safe / 3 default (no dependend children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SessionEnv" "Start" 4

# #ote Desktop Services				4 safe / 3 default / 4 default after scripts (one dependend child)
# children: #ote Desktop Services UserMode Port Redirector (UmRdpService)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\TermService" "Start" 4			

# #ote Desktop Services UserMode Port Redirector		4 safe / 3 default (no dependend children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\UmRdpService" "Start" 4

# #ote Procedure Call (RPC) Locator Service			4 should be safe / 3 default (no dependend children)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RpcLocator" "Start" 4

# Microsoft Store Install Service (marked #)			3 safe default / 4 safe-under-conditions
# condition: disable if you dont have windows store
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\InstallService" "Start" 3

# Themes						4 safe-under-condition / 2 safe default
# condition: if you dont need to manage themes (setting wallpaper, colour, etc still works)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Themes" "Start" 2

# Windows Search 					4 safe-under-condition / 2 safe default
# condition: if you only need search for starting programs with entries in startmenu
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WSearch" "Start" 2
Write-Host "`n"



Write-Host "***might affect VR***"

# Windows Perception Simulation Service		4 safe-under-condition / default 3 (no dependent children)
# condition: test if it affects vr
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\perceptionsimulation" "Start" 3

# Windows Perception Service			4 safe-under-condition / default 3 (no dependent children)
# condition: test if it affects vr
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\spectrum" "Start" 3

# MixedRealityOpenXRSvc (Windows 11 only)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MixedRealityOpenXRSvc" "Start" 4
Write-Host "`n"

