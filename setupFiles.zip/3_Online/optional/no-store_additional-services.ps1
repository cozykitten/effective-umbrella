# services necessary for windows store and microsoft account

# Background Intelligent Transfer Service		//default 3	//might cause issues with WU
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\BITS" "Start" 3

# Microsoft Store Install Service				//default 3
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\InstallService" "Start" 4

# Microsoft Update Health Service				//default 4

# Network Connection Broker				//default 3
# children: Connected Devices Platform Service (CDPSvc)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NcbService" "Start" 4

# Connected Devices Platform Service			//default 2
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\CDPSvc" "Start" 4

# Web Account Manager					//default 3
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\TokenBroker" "Start" 4

# Windows PushToInstall Service				//default 3
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PushToInstall" "Start" 4
