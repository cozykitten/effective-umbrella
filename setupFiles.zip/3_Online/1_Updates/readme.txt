
1. Updates

Open Windows Security, and click on "Virus & threat protection" in the left sidebar menu.
It might have deleted the hosts file and might show a red icon.
Check the "Protection history" below the "Quick scan" button.
If it shows that it blocked a "HostsFileHijack" and quarantined the file, expand the entry and restore the file and allow it's changes.

Connect to the internet.

Open admin Powershell
In Powershell window

copy paste : Get-CimInstance -Namespace "Root\cimv2\mdm\dmmap" -ClassName "MDM_EnterpriseModernAppManagement_AppManagement01" | Invoke-CimMethod -MethodName UpdateScanMethod

or open store and find the get updates button
Then do windows updates and RESTART.

Once you're back check OOSU10 again, sometimes updates affect settings.
If you want you can disable some windows update components in OOSU10 now too.
F.e. updating drivers might get in the way with your future nvidia driver installation.

run 2_Logon\5_Telemetry again
run the same Sophia script preset you used previously again, now "Teams" might show up in the uninstall apps popup.



2. Testing

testing now before installing apps & doing manual settings, in case something doesn't work it has only been running scripts until now anyway.

please test that those all work if you kept those components.

wifi
bluetooth
xbox (with sign in)