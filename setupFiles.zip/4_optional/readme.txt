Explorer Patcher: https://github.com/valinet/ExplorerPatcher
-> see ExplorerPatcher.md for details
if you use explorer patcher you dont need disable rounded corners since it includes an option for that.

Disable Rounded Corners: https://github.com/valinet/Win11DisableRoundedCorners
-> see DisableRoundedCorners.md for details

Winaero Tweaker: https://winaero.com/winaero-tweaker/#download
Winaero Tweaker allows you to f.e. hide the notification center button, customise your context menu and File Explorer entries, etc
- > see WinaeroTweaker.txt for download details