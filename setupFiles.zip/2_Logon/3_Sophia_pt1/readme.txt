1. Run SophiaScriptWrapper.exe in the Sophia Script Wrapper folder.

2. If you have any up to date preset you can import it (click top left for import).
   You can also import any of the "recommended", "minimal", etc presets if they are compatible with your current version.
   Otherwise you can use the presets as reference.
   You should still read through the settings and tweak them to your liking.

3. Check "UI & Personalisation", you might want to resize the window to fit everything.
   There are some settings you might want to change, such as windows and app colour mode on the right,
   or the Quick Access stuff for File Explorer on the left.

4. You can hover over each setting to read what it does.

5. When you're satisfied with your selection click the last tab "Console Output" and click "Refresh Console".

6. If you changed something export it as new preset now and save it in the Sophia Script folder next to the other presets. 
   Next close the Wrapper window and open the Sophia Script folder in File Explorer.
   Open Powershell as administrator (search in windows search).
   Go inside the "Sophia Script for Windows" folder and copy the path from the address bar.
   In powershell:
   type "pushd" then paste the path by rightclicking
   copy paste : Set-ExecutionPolicy bypass -scope process -force
   then type the name of your new preset or the one you want to use and use tab for autocompletion, then hit enter to run it.

7. Hit 'Y' for "yes, I changed some stuff" (you're supposed to tweak it to your liking instead of blindly running it).

8. It will bring up some popup windows asking you to select features or Universal Windows Platform (UWP) apps to uninstall.
   This is optional, uninstall anything you don't need (see the list below), if there is nothing to delete, just close the popup.
   Generally it should be fine to disable most or all of the scheduled tasks, while leaving the features and apps alone.


Schedulet tasks:
Proxy: Sends telemetry data if enabled
- save to delete

XblGameSaveTask: I don't know, its only there if you left Xbox components
- better keep it

Features:
XPS Document Writer: Microsofts unpopular alternative of PDF 
- safe to delete unless you're working with XPS files

Media Features: Contains Windows Media Player
- don't delete it unless you never listen to offline sound files or have a different app

Internet Printing Client: printing over network support
- delete only if you don't print from your pc anyway

Remote Differential Compression API support: might be used by some applications
- better keep it

WCF Services: dunno
- so better keep it

SMB File Sharing Support: used for file sharing between old versions of Windows or Linux or macOS devices
- save to delete


Optional Features:
Steps Recorder: desktop recording feature for remote assistance
- safe to delete (if not already with toolkit)

quick assist: remote assistance stuff
- safe to delete

leave the others


UWP Apps:
You already didn't include the ones you don't want to so everything here should be stuff you want.
