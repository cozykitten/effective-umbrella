run OOSU10, click on "File" and "Import Settings" and select the .cfg file in this folder.

those are just recommendations, you can read what every setting does by clicking it.

RESTART after this