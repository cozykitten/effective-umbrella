In the still open admin Powershell:
copy paste : 7_Services\DisableServices.ps1

copy paste: Get-MMAgent
then configure as desired, recommended are:

copy paste: Enable-MMagent -PageCombining
copy paste: Enable-MMagent -ApplicationPreLaunch
copy paste: Enable-MMagent -MemoryCompression
