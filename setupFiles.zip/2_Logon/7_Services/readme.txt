In the still open admin Powershell:
copy paste : 7_Services\DisableServices.ps1