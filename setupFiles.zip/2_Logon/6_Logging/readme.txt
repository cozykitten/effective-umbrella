
open regedit (win + r -> "regedit" or type regedit in search)
copy paste this path in the address bar of the registry window and hit enter

Computer\HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger

export the Autologger key (folder) in the left column by right clicking it -> export, save it as "autologger_backup.reg" in this folder next to the readme and autologger.bat

In the still open admin Powershell:
copy paste : auditpol /backup /file:6_Logging\auditpol_backup.txt
copy paste : auditpol /set /category:* /success:disable /failure:enable

right click Autologger.bat -> run as administrator

when that's done continue with the next