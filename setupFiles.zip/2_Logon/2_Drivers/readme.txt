start with your chipset drivers, then reboot, then do the rest

after installing nvidia drivers set your refreshrate to "not 60" in nvidia control panel -> change resolution

reboot after you installed everything in this folder, then continue with the rest of 2_Logon