open Windows Security, in the menu on the left, select "Virus & threat protection" and turn off "Real-time protection" for now.

depending whether you want to keep xbox related settings or not, copy the files from the yes-xbox or no-xbox folder respectively
and paste them in this folder alongside all the other scripts. 

If you have Sophia's Powershell window still open you can close it.
Open a new Powershell window as administrator and copy the path to the current folder from the explorer address bar.

In powershell:
type "pushd" and paste the copied path by rightclicking.
copy paste : Set-ExecutionPolicy bypass -scope process -force
then start running all the .ps1 scripts, start typing their name, f.e. "block" and then use Tab for autocompletion.

Skip over NSudo.

for "optimize-windows-update":
in case you want windows to schedule updates at a certain day and time, right click -> edit the file and uncomment line 13 and 14.
set the day to the number you like, it starts with 1 Sunday and goes to 7 Saturday
if you dont edit the file it will stay at default: every day
you can also change the time (line 14)

You can try right clicking -> run as administrator on "access_denied.bat".
If it runs and shows "Success" in the terminal window you can skip the next part and skip to the last line of this file.

After running all .ps1 scripts, run NSudo.
In the "Open" field type "cmd", then hit run.
A new terminal should open in the current folder, run access_denied.bat (use autocompletion).
Then you can close the new terminal and NSudo.

In the still open Powershell window type "pushd ..\" and just leave it open, then continue in the next step.