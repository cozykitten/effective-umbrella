shift + right click -> open powershell window here

copy paste : Set-ExecutionPolicy bypass -scope process -force
then type "d" and use tab for autocompletion, then hit enter to run it.